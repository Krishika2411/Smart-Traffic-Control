SMART TRAFFIC SIGNAL SIMULATION — SIX INDIVIDUAL C++ PROGRAMS

These six independent C++ files correspond exactly to the six options shown
in the user's screenshot.

1. 1_add_vehicles.cpp
2. 2_display_road_status.cpp
3. 3_run_smart_signal_cycle.cpp
4. 4_traffic_density_ranking.cpp
5. 5_show_statistics.cpp
6. 6_exit_program.cpp

Compile and run ONE file at a time, for example:
g++ 1_add_vehicles.cpp -o demo
./demo

On Windows, run demo.exe after compiling.

Important:
- Each file has its own main() function.
- Option 1 accepts user input. Options 2–5 use sample data so they can be
  demonstrated individually without needing another program's state.
- Option 6 demonstrates the exit message by itself.
- The six files are separate demonstrations, not one integrated program.
- The complete original program remains the file smart_traffic_signal.cpp.
