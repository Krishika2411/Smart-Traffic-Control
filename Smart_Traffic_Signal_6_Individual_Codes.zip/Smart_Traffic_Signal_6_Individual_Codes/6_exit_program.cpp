// MENU OPTION 6: Exit
#include <iostream>
using namespace std;

int main() {
    cout << "========================================\n";
    cout << "   SMART TRAFFIC SIGNAL SIMULATION\n";
    cout << "========================================\n";
    cout << "You selected Option 6: Exit\n";
    cout << "Thank you for using Smart Traffic Signal Simulation.\n";
    cout << "Program terminated successfully.\n";
    return 0;
}
