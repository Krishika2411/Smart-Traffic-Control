// MENU OPTION 2: Display road status
#include <iostream>
#include <queue>
#include <string>
#include <iomanip>
using namespace std;

struct Road {
    string name;
    queue<int> vehicles;
    int totalArrived = 0;
    int totalServed = 0;
};

int main() {
    Road roads[4];
    roads[0].name = "North";
    roads[1].name = "South";
    roads[2].name = "East";
    roads[3].name = "West";

    // Example data to make the status table demonstrable.
    int waiting[] = {5, 2, 7, 0};
    int served[] = {3, 4, 2, 0};

    for (int i = 0; i < 4; ++i) {
        roads[i].totalArrived = waiting[i] + served[i];
        roads[i].totalServed = served[i];
        for (int j = 0; j < waiting[i]; ++j)
            roads[i].vehicles.push(j + 1);
    }

    cout << "================ ROAD STATUS ================\n";
    cout << left << setw(12) << "Road"
         << setw(14) << "Waiting"
         << setw(14) << "Arrived"
         << setw(14) << "Served" << "\n";
    cout << "----------------------------------------------\n";

    for (const Road& road : roads) {
        cout << left << setw(12) << road.name
             << setw(14) << road.vehicles.size()
             << setw(14) << road.totalArrived
             << setw(14) << road.totalServed << "\n";
    }

    cout << "----------------------------------------------\n";
    cout << "Note: This standalone demonstration uses sample data.\n";
    return 0;
}
