// MENU OPTION 5: Show traffic statistics
#include <iostream>
#include <queue>
#include <string>
#include <iomanip>
using namespace std;

struct Road {
    string name;
    queue<int> vehicles;
    int totalArrived = 0;
    int totalServed = 0;
    int totalGreenSeconds = 0;
};

int main() {
    Road roads[4];
    roads[0].name = "North";
    roads[1].name = "South";
    roads[2].name = "East";
    roads[3].name = "West";

    // Sample totals for demonstration.
    int arrived[] = {10, 8, 12, 5};
    int served[] = {6, 4, 9, 2};
    int green[] = {20, 16, 30, 10};

    int totalArrived = 0, totalServed = 0;
    int totalWaiting = 0, totalGreen = 0;

    for (int i = 0; i < 4; ++i) {
        roads[i].totalArrived = arrived[i];
        roads[i].totalServed = served[i];
        roads[i].totalGreenSeconds = green[i];

        int remaining = arrived[i] - served[i];
        for (int j = 0; j < remaining; ++j)
            roads[i].vehicles.push(j + 1);

        totalArrived += roads[i].totalArrived;
        totalServed += roads[i].totalServed;
        totalWaiting += static_cast<int>(roads[i].vehicles.size());
        totalGreen += roads[i].totalGreenSeconds;
    }

    cout << "============= TRAFFIC STATISTICS =============\n";
    cout << "Total vehicles arrived   : " << totalArrived << "\n";
    cout << "Total vehicles served    : " << totalServed << "\n";
    cout << "Vehicles still waiting   : " << totalWaiting << "\n";
    cout << "Total allocated green time: " << totalGreen << " seconds\n";

    if (totalArrived > 0) {
        cout << fixed << setprecision(2);
        cout << "Served percentage        : "
             << (100.0 * totalServed / totalArrived) << "%\n";
    } else {
        cout << "Served percentage        : N/A\n";
    }

    cout << "\nPer-road summary:\n";
    for (const Road& road : roads) {
        cout << road.name
             << " | Waiting: " << road.vehicles.size()
             << " | Arrived: " << road.totalArrived
             << " | Served: " << road.totalServed
             << " | Green time: " << road.totalGreenSeconds << " sec\n";
    }

    cout << "Note: This standalone demonstration uses sample data.\n";
    return 0;
}
