// MENU OPTION 3: Run one smart signal cycle
#include <iostream>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

struct Road {
    string name;
    queue<int> vehicles;
};

struct PriorityItem {
    int vehicleCount;
    int roadIndex;
};

struct ComparePriority {
    bool operator()(const PriorityItem& a, const PriorityItem& b) const {
        if (a.vehicleCount == b.vehicleCount)
            return a.roadIndex > b.roadIndex;
        return a.vehicleCount < b.vehicleCount;
    }
};

int calculateGreenTime(int vehicles) {
    return min(60, max(10, 10 + 2 * vehicles));
}

int main() {
    Road roads[4];
    roads[0].name = "North";
    roads[1].name = "South";
    roads[2].name = "East";
    roads[3].name = "West";

    // Example traffic: North=4, South=9, East=3, West=6.
    int waiting[] = {4, 9, 3, 6};
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < waiting[i]; ++j)
            roads[i].vehicles.push(j + 1);

    priority_queue<PriorityItem, vector<PriorityItem>, ComparePriority> pq;
    for (int i = 0; i < 4; ++i)
        if (!roads[i].vehicles.empty())
            pq.push({static_cast<int>(roads[i].vehicles.size()), i});

    cout << "========== SMART SIGNAL CYCLE ==========\n";

    if (pq.empty()) {
        cout << "No waiting vehicles. All signals remain idle.\n";
        return 0;
    }

    PriorityItem selected = pq.top();
    Road& road = roads[selected.roadIndex];
    int waitingBefore = static_cast<int>(road.vehicles.size());
    int greenSeconds = calculateGreenTime(waitingBefore);
    int servedNow = min(greenSeconds / 2, waitingBefore);

    for (int i = 0; i < servedNow; ++i)
        road.vehicles.pop();

    cout << "Selected road          : " << road.name << "\n";
    cout << "Signal                 : GREEN\n";
    cout << "Green duration         : " << greenSeconds << " seconds\n";
    cout << "Vehicles served        : " << servedNow << "\n";
    cout << "Vehicles still waiting : " << road.vehicles.size() << "\n";
    cout << "Other road signals     : RED\n";
    cout << "DSA concepts: Priority Queue (Heap), Queue, Greedy selection.\n";
    cout << "Note: This is a simplified educational simulation.\n";
    return 0;
}
