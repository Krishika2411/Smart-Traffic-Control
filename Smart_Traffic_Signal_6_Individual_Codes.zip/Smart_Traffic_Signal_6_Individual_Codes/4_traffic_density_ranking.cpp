// MENU OPTION 4: Show traffic density ranking
#include <iostream>
#include <queue>
#include <string>
#include <algorithm>
using namespace std;

struct Road {
    string name;
    queue<int> vehicles;
};

int main() {
    Road roads[4];
    roads[0].name = "North";
    roads[1].name = "South";
    roads[2].name = "East";
    roads[3].name = "West";

    // Example waiting vehicle counts.
    int waiting[] = {5, 2, 7, 7};
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < waiting[i]; ++j)
            roads[i].vehicles.push(j + 1);

    int order[] = {0, 1, 2, 3};

    sort(order, order + 4, [&](int a, int b) {
        if (roads[a].vehicles.size() == roads[b].vehicles.size())
            return roads[a].name < roads[b].name;
        return roads[a].vehicles.size() > roads[b].vehicles.size();
    });

    cout << "========= TRAFFIC DENSITY RANKING =========\n";
    for (int rank = 0; rank < 4; ++rank) {
        int i = order[rank];
        cout << rank + 1 << ". " << roads[i].name
             << " - " << roads[i].vehicles.size()
             << " waiting vehicle(s)\n";
    }

    cout << "Note: This standalone demonstration uses sample data.\n";
    cout << "DSA concept: Sorting in descending order of queue size.\n";
    return 0;
}
