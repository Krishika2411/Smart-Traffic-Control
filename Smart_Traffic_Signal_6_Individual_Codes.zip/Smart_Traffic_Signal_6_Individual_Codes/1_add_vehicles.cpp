// MENU OPTION 1: Add vehicles to a road
#include <iostream>
#include <queue>
#include <string>
using namespace std;

struct Road {
    string name;
    queue<int> vehicles;
    int totalArrived = 0;
};

int main() {
    Road roads[4];
    roads[0].name = "North";
    roads[1].name = "South";
    roads[2].name = "East";
    roads[3].name = "West";

    int choice, count;
    cout << "===== ADD VEHICLES TO A ROAD =====\n";
    cout << "1. North\n2. South\n3. East\n4. West\n";
    cout << "Choose road (1-4): ";

    if (!(cin >> choice) || choice < 1 || choice > 4) {
        cout << "Invalid road choice.\n";
        return 0;
    }

    cout << "How many vehicles arrived? ";
    if (!(cin >> count) || count < 0 || count > 100000) {
        cout << "Enter a valid non-negative vehicle count.\n";
        return 0;
    }

    Road& road = roads[choice - 1];
    for (int i = 0; i < count; ++i) {
        road.vehicles.push(road.totalArrived + i + 1);
    }
    road.totalArrived += count;

    cout << "\nSUCCESS: " << count << " vehicle(s) added to "
         << road.name << " Road.\n";
    cout << "Vehicles currently waiting on this road: "
         << road.vehicles.size() << "\n";
    cout << "DSA concept: Queue (FIFO - First In, First Out).\n";
    return 0;
}
